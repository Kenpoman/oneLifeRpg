
/**
 * Write a description of class Fighter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Fighter
{
    // instance variables - replace the example below with your own
    private int maxHp, currentHp, strength, dexterity, intelligence;
    private String name;

    /**
     * Constructor for objects of class Fighter
     */
    public Fighter(String adventurer)
    {
        // initialise instance variables
        maxHp = 30;
        currentHp = 30;
        strength = 10;
        dexterity = 10;
        intelligence = 10;
        name = adventurer;
    }
}
